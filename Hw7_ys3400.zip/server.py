from flask import Flask
from flask import render_template
from flask import Response, request, jsonify
app = Flask(__name__)


data=[
    {
    "id": "1",
    "CharacterName":"Arya Stark",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMTk5MTYwNDc0OF5BMl5BanBnXkFtZTcwOTg2NDg1Nw@@._V1._SX100_SY140_.jpg",
    "ActorName":"Maisie Williams",
    #"AlliedWith":["Lady Crane","Jaqen H'ghar","Hot Pie","Syrio Forel"],
    "EnemyWith":["Tywin Lannister","Joffrey Baratheon","Walder Frey","Gregor The Mountain Clegane"],
    "NumOfManKilled":15,
    "description":"Princess Arya Stark is the third child and second daughter of Lord Eddard Stark and his wife, Lady Catelyn Stark. She is the sister of the incumbent Westerosi monarchs, Sansa, Queen in the North, and Brandon, King of the Andals and the First Men.After narrowly escaping the persecution of House Stark by House Lannister, Arya is trained as a Faceless Man at the House of Black and White in Braavos, using her abilities to avenge her family. Upon her return to Westeros, she exacts retribution for the Red Wedding by exterminating the Frey male line."
    },
    {
    "id": "2",
    "CharacterName":"Jaime Lannister",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMjIzMzU1NjM1MF5BMl5BanBnXkFtZTcwMzIxODg4OQ@@._V1_.jpg",
    "ActorName":"Nikolaj Coster-Waldau",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Catelyn Stark","Daenerys Targaryen","Robb Stark","Jory Cassel"],
    "NumOfManKilled":13,
    "description":"Ser Jaime Lannister was the elder son of Lord Tywin Lannister, younger twin brother of Queen Cersei Lannister, and older brother of Tyrion Lannister. He was involved in an incestuous relationship with Cersei, and unknown to most, he was the biological father of her three bastard children, Joffrey, Myrcella, and Tommen, as well as her unborn child."
    },
    {
    "id": "3",
    "CharacterName":"Jon Snow",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMTkwMjUxMDk2OV5BMl5BanBnXkFtZTcwMzg3MTg4OQ@@._V1_.jpg",
    "ActorName":"Kit Harington",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Cersei Lannister","Daenerys Targaryen","Robb Stark","Ramsay Bolton"],
    "NumOfManKilled":8,
    "description":"Jon Snow, born Aegon Targaryen, is the son of Lyanna Stark and Rhaegar Targaryen, the late Prince of Dragonstone. From infancy, Jon is presented as the bastard son of Lord Eddard Stark, Lyanna's brother, and raised alongside Eddard's lawful children at Winterfell. Jon's true parentage is kept secret from everyone, including Jon himself, in order to protect him from those that sought the complete annihilation of House Targaryen."
    },
    {
    "id": "4",
    "CharacterName":"Daenerys Targaryen",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMjA4MzIxMTQwMF5BMl5BanBnXkFtZTcwMzY2NDg1Nw@@._V1_SY1000_CR0,0,810,1000_AL_.jpg",
    "ActorName":"Emilia Clarke",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Jaime Lannister","Robert Baratheon","Eddard Stark","Viserys Targaryen"],
    "NumOfManKilled":20,
    "description":"Queen Daenerys I Targaryen, also known as Daenerys Stormborn, and colloquially known as Dany, was briefly Queen of the Andals and the First Men and the twenty-first ruler of the Seven Kingdoms. She was also the Khaleesi of the Great Grass Sea and the Queen of Meereen. She was the younger sister of Rhaegar Targaryen and Viserys Targaryen and the only daughter of King Aerys II Targaryen and Queen Rhaella Targaryen. Her father was ousted from the Iron Throne during Robert's Rebellion."
    },
    {
    "id": "5",
    "CharacterName":"Jorah Mormont",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMTkzNTcxMDI2NV5BMl5BanBnXkFtZTcwMzgxNzI4OQ@@._V1._CR225,437,407,405_.jpg",
    "ActorName":"Iain Glen",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Eddard Stark","Viserys Targaryen"],
    "NumOfManKilled":3,
    "description":"Ser Jorah Mormont was an exiled Northern lord from Westeros, previously living in Essos. He had sworn fealty to his fellow exile Daenerys Targaryen, the Targaryen claimant to the Iron Throne, and was the first to help her adapt to life as a khaleesi of the Dothraki."
    },
    {
    "id": "6",
    "CharacterName":"Sansa Stark",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BNjAwMjE2NDExNF5BMl5BanBnXkFtZTcwODAwODg4OQ@@._V1_SY1000_CR0,0,806,1000_AL_.jpg",
    "ActorName":"Sophie Turner",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Cersei Lannister","Ilyn Payne","Joffrey Baratheon"],
    "NumOfManKilled":5,
    "description":"Queen Sansa Stark is the eldest daughter of Lord Eddard Stark and his wife, Lady Catelyn, sister of Robb, Arya, Bran, and Rickon Stark, and half-sister of Jon Snow; though truthfully is his cousin."
    },
    {
    "id": "7",
    "CharacterName":"Tyrion Lannister",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMjA2MDAwOTI0OV5BMl5BanBnXkFtZTcwNjA3NDg1Nw@@._V1_SX1500_CR0,0,1500,999_AL_.jpg",
    "ActorName":"Peter Dinklage",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Brynden Tully","Catelyn Stark","Lysa Arryn","Joffrey Baratheon"],
    "NumOfManKilled":13,
    "description":"Lord Tyrion Lannister is the youngest child of Lord Tywin Lannister and younger brother of Cersei and Jaime Lannister. A dwarf, he uses his wit and intellect to overcome the prejudice he faces. He is the current Lord of Casterly Rock and Hand of the King to Brandon Stark."
    },
    {
    "id": "8",
    "CharacterName":"Melisandre",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BNTE5OTI0OTA0OV5BMl5BanBnXkFtZTcwODczOTAzOQ@@._V1_SY1000_CR0,0,666,1000_AL_.jpg",
    "ActorName":"Carice van Houten",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Bloodraven","Indira Varma"],
    "NumOfManKilled":6,
    "description":"Melisandre, often referred to as the Red Woman or the Red Witch, was a Red Priestess in the religion of R'hllor, and had been a close counselor to King Stannis Baratheon in his campaign to take the Iron Throne."
    },
    {
    "id": "9",
    "CharacterName":"Theon Greyjoy",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMTM3ODUyOTY3N15BMl5BanBnXkFtZTcwNjI4MTg4OQ@@._V1_.jpg",
    "ActorName":"Alfie Allen",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Hodor","Rodrik Cassel","Bran Stark"],
    "NumOfManKilled":8,
    "description":"Theon Greyjoy was the youngest son of King Balon Greyjoy of the Iron Islands and the younger brother of Rodrik, Maron, and Yara Greyjoy."
    },
    {
    "id": "10",
    "CharacterName":"Petyr Baelish",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMTQ1MjE3OTc3M15BMl5BanBnXkFtZTcwODgzODg4OQ@@._V1_.jpg",
    "ActorName":"Aidan Gillen",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Arya Stark","Eddard Stark","Tyrion Lannister"],
    "NumOfManKilled":19,
    "description":"Lord Petyr Baelish, popularly called Littlefinger, was the Master of Coin on the small council under King Robert Baratheon and King Joffrey Baratheon. He was a skilled manipulator and used his ownership of brothels in King's Landing to both acquire vast wealth and accrue intelligence on political rivals. "
    }, 
    {
    "id": "11",
    "CharacterName":"Varys",
    "CharacterImage":"https://images-na.ssl-images-amazon.com/images/M/MV5BMzg1Y2NiYTYtNDY0Yi00OGMwLWJjZjktZDVlNDE1Y2M3MTMzXkEyXkFqcGdeQXVyMjk3NTUyOTc@._V1_.jpg",
    "ActorName":"Conleth Hill",
    #"AlliedWith":["Tywin Lannister","The Mountain","Qyburn","Joffrey Baratheon"],
    "EnemyWith":["Cersei Lannister","Ilyn Payne","Joffrey Baratheon"],
    "NumOfManKilled":19,
    "description":"Varys, popularly known as the Spider, was the eunuch Master of Whisperers on the Baratheon small council until he was forced to flee King's Landing with Tyrion Lannister. He was a skilled manipulator and commanded a network of informants across two continents."
    },
]


def containes(cur_list,word):
    for ea in cur_list:
        if word.lower() in ea.lower():
            return True
    return False


# ROUTES

@app.route('/')
def index():
    res = []
    for item in data:
        res.append(item["CharacterName"])
        if len(res)>=3:
            break
    return render_template('index.html', data=data[:3], names=res)


@app.route('/search', methods=['GET', 'POST'])
def search():
    print(request)
    idx= request.url.index("_key=")
    keys = request.url[idx+5:]
    print(keys)
    print("keys")
    res = []
    for item in data:
        if keys.lower() in item["CharacterName"].lower():
            res.append(item)
        elif keys.lower() in item["description"].lower():
            res.append(item)
        elif containes(item["EnemyWith"],keys):
            res.append(item)

    print(res)
    return render_template('search.html', result=res,key=keys)


@app.route('/view/<id>')
def view(id=0):
    item=None
    for item in data:
        if int(item["id"]) == int(id):
            return render_template('view.html', item=item)

    return render_template('view.html', item=item)

@app.route('/edit/<id>')
def edit(id):
    # get the item with the exact id
    for item in data:
        if int(item["id"]) == int(id):
            return render_template('edit.html', item=item)
    return render_template('edit.html', item=item)

@app.route('/add')
def add():
    return render_template("add.html")

@app.route('/add_item', methods=['GET', 'POST'])
def add_item():
    new_item = request.get_json()
    new_item["id"] = len(data)+1
    print(new_item["EnemyWith"])
    data.append(new_item)
    return jsonify(url="view/"+str(new_item["id"]))


@app.route('/edit_item', methods=['GET', 'POST'])
def edit_item():
    json_data = request.get_json()
    print(json_data)
    id = json_data["id"]
    for i in range(len(data)):
        item=data[i]
        if int(item["id"]) == int(id):
            for ea in json_data:
                data[i][ea]=json_data[ea]
    return jsonify(0)


if __name__ == '__main__':
   app.run(debug = True)




