function displayInfo() {
    
    $("#edit").prop("href", "/edit/" + item["id"])
    $("#name22").append(item["CharacterName"]);
    $("#actor_name").append(item["ActorName"]);
    $("#killed_num").append(item["NumOfManKilled"]);

    $("#image").append(item["CharacterImage"])

    $("#description").append(item["description"]);

    $.each(item["EnemyWith"], function (index, item) { 

        $("#enemys").append(item);
        $("#enemys").append("\r\n")
    });
}

function check_string(input) {
    var warning=""
    if (input==""){
        warning="fillin something"
    }
    else if (input.replace(/\s+/g, "").length == 0){
        warning="invalid string"
    }
    if (warning=="") return null;
    var warn_ele=$("<div class='warning'></div>")
    warn_ele.html(warning)
    return warn_ele
}


function check_int(input) {
    var warning=""
    if (input==""){
        warning="fillin something"
    }
    else if (input.replace(/\s+/g, "").length == 0){
        warning="invalid input"
    }
    else if (!/^\d+$/.test(input.replace(/\s+/g, ""))){
        warning="invalid number"
    }
    if (warning=="") return null;
    var warn_ele=$("<div class='warning'></div>")
    warn_ele.html(warning)
    return warn_ele
}


function check_input(input) {
    var valid = true
    var warning1 = check_string(input["CharacterName"])
    if (warning1 != null){
        $("#name-warning").append(warning1)
        valid=false
    }
    var warning2 = check_string(input["CharacterImage"])
    if (warning2 != null){
        $("#image-warning").append(warning2)
        valid=false
    }
    var warning3 = check_int(input["NumOfManKilled"])
    if (warning3 != null){
        $("#killed_num-warning").append(warning3)
        valid=false
    }
    var warning4 = check_string(input["ActorName"])
    if (warning4 != null){
        $("#actor_name-warning").append(warning4)
        valid=false
    }
    var warning5 = check_string(input["description"])
    if (warning5 != null){
        $("#description-warning").append(warning5)
        valid=false
    }
    var warning6 = check_string(input["EnemyWith"])
    if (warning6 != null){
        $("#enemys-warning").append(warning6)
        valid=false
    }
    return valid;
}

$(document).ready(function () {
    displayInfo()

    $("#submit").click(function () { 

        $(".warning").each(function(){
            $(this).empty()
        })

        var item2 = {
            "id":item["id"],
            "CharacterName": $("#name22").val(),
            "CharacterImage": $("#image").val(),
            "NumOfManKilled": $("#killed_num").val(),
            "ActorName": $("#actor_name").val(),
            "EnemyWith": $("#enemys").val(),
            "description":$("#description").val(),
        }

        var valid = check_input(item2)
        //console.log(item2)

        if (valid == true) {
            
            var enemies=item2["EnemyWith"].split(/\r?\n/);
            item2["EnemyWith"]=enemies
            
            $.ajax({
                type: "POST",
                url: "/edit_item",
                dataType : "json",
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(item2),
                success: function (response) {
                    window.location.href = "http://127.0.0.1:5000/view/" + item["id"]
                },
                error: function(request, status, error){
                    console.log("Error");
                    console.log(request)
                }
            });
        }
    });

    $("#discard").click(function (e) { 
        console.log("disard")
        e.preventDefault();
        document.getElementById("favDialog").showModal();
    });
    $("#confirmBtn").click(function () { 
        window.location.href = "http://127.0.0.1:5000/view/" + item["id"]
    });
});
