function check_string(input) {
    var warning=""
    if (input==""){
        warning="fillin something"
    }
    else if (input.replace(/\s+/g, "").length == 0){
        warning="invalid string"
    }
    if (warning=="") return null;
    var warn_ele=$("<div class='warning'></div>")
    warn_ele.html(warning)
    return warn_ele
}


function check_int(input) {
    var warning=""
    if (input==""){
        warning="fillin something"
    }
    else if (input.replace(/\s+/g, "").length == 0){
        warning="invalid input"
    }
    else if (!/^\d+$/.test(input.replace(/\s+/g, ""))){
        warning="invalid number"
    }
    if (warning=="") return null;
    var warn_ele=$("<div class='warning'></div>")
    warn_ele.html(warning)
    return warn_ele
}


function check_input(input) {
    var valid = true
    var warning1 = check_string(input["CharacterName"])
    if (warning1 != null){
        $("#name-warning").append(warning1)
        valid=false
    }
    var warning2 = check_string(input["CharacterImage"])
    if (warning2 != null){
        $("#image-warning").append(warning2)
        valid=false
    }
    var warning3 = check_int(input["NumOfManKilled"])
    if (warning3 != null){
        $("#killed_num-warning").append(warning3)
        valid=false
    }
    var warning4 = check_string(input["ActorName"])
    if (warning4 != null){
        $("#actor_name-warning").append(warning4)
        valid=false
    }
    var warning5 = check_string(input["description"])
    if (warning5 != null){
        $("#description-warning").append(warning5)
        valid=false
    }
    var warning6 = check_string(input["EnemyWith"])
    if (warning6 != null){
        $("#enemys-warning").append(warning6)
        valid=false
    }
    return valid;
}


$(document).ready(function () {
    $("#submit").click(function () {
        $(".warning").each(function(){
            $(this).empty()
        })
        
        var item = {
            "CharacterName": $("#name").val(),
            "CharacterImage": $("#image").val(),
            "NumOfManKilled": $("#killed_num").val(),
            "ActorName": $("#actor_name").val(),
            "EnemyWith": $("#enemys").val(),
            "description":$("#description").val(),
        }

        var valid = check_input(item)

        if (valid == true) {

            var enemies=item["EnemyWith"].split(/\r?\n/);
            item["EnemyWith"]=enemies

            $.ajax({
                type: "POST",
                url: "add_item",
                dataType : "json",
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify(item),
                success: function (response) {
                    $("#submit-row").empty()
                    var url = response["url"]
                    var link = $("<a href='" + url + "'>Goto the newly created page, see it here<\a>")
                    $("#submit-row").append(link);
                    $.each([$("#name"),$("#image"),$("#killed_num"),$("#actor_name"),$("#enemys"),$("#description")], function(idx,item){
                        console.log(item)
                        item.val("")
                    })
                    $("#name").focus()
                    
                },
                error: function(request, status, error){
                    console.log("Error");
                    console.log(error)
                }
            });
            
        }

        
    });
});